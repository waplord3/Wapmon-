while true
do
echo "Starting SUHAIL-XMD!"
node .
done
